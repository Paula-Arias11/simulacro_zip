-- One admin user, named admin1 with passwor 4dm1n and authority admin
INSERT INTO authorities(id,authority) VALUES (1,'ADMIN');
INSERT INTO appusers(id,username,password,authority) VALUES (1,'admin1','$2a$10$nMmTWAhPTqXqLDJTag3prumFrAJpsYtroxf0ojesFYq0k4PmcbWUS',1);

-- Ten player users, named player1 with passwor 0wn3r
INSERT INTO authorities(id,authority) VALUES (2,'PLAYER');
INSERT INTO appusers(id,username,password,authority,rating) VALUES (4,'player1','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1500);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (5,'player2','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1550);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (6,'player3','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1600);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (7,'player4','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1450);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (8,'player5','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1700);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (9,'player6','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1750);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (10,'player7','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1800);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (11,'player8','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1400);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (12,'player9','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1650);
INSERT INTO appusers(id,username,password,authority,rating) VALUES (13,'player10','$2a$10$DaS6KIEfF5CRTFrxIoGc7emY3BpZZ0.fVjwA3NiJ.BjpGNmocaS3e',2,1900);




-- Match 15: partida ya existente, usada de ejemplo y por el desafío 1 (finalizada, gana el blanco)
INSERT INTO chess_board (id, white_turn, jaque, current_turn_start) VALUES (15, 0, 0, null);
INSERT INTO chess_match(id, name, white_id, black_id, winner_id, board_id, type, start, finish, turn_duration) VALUES
                        (15, 'new', 4, 5, 4, 15, 0, '2026-07-01 09:00:00', '2026-07-01 09:20:00', 600);

INSERT INTO Position(id, x, y) VALUES
    (1, 1, 1),
    (2, 2, 1),
    (3, 3, 1),
    (4, 4, 1),
    (5, 5, 1),
    (6, 6, 1),
    (7, 7, 1),
    (8, 8, 1),
    (9, 1, 2),
    (10, 2, 2),
    (11, 3, 2),
    (12, 4, 2),
    (13, 5, 2),
    (14, 6, 2),
    (15, 7, 2),
    (16, 8, 2),
    (17, 1, 3),
    (18, 2, 3),
    (19, 3, 3),
    (20, 4, 3),
    (21, 5, 3),
    (22, 6, 3),
    (23, 7, 3),
    (24, 8, 3),
    (25, 1, 4),
    (26, 2, 4),
    (27, 3, 4),
    (28, 4, 4),
    (29, 5, 4),
    (30, 6, 4),
    (31, 7, 4),
    (32, 8, 4),
    (33, 1, 5),
    (34, 2, 5),
    (35, 3, 5),
    (36, 4, 5),
    (37, 5, 5),
    (38, 6, 5),
    (39, 7, 5),
    (40, 8, 5),
    (41, 1, 6),
    (42, 2, 6),
    (43, 3, 6),
    (44, 4, 6),
    (45, 5, 6),
    (46, 6, 6),
    (47, 7, 6),
    (48, 8, 6),
    (49, 1, 7),
    (50, 2, 7),
    (51, 3, 7),
    (52, 4, 7),
    (53, 5, 7),
    (54, 6, 7),
    (55, 7, 7),
    (56, 8, 7),
    (57, 1, 8),
    (58, 2, 8),
    (59, 3, 8),
    (60, 4, 8),
    (61, 5, 8),
    (62, 6, 8),
    (63, 7, 8),
    (64, 8, 8);

INSERT INTO piece_type (name, points) VALUES
  ('KING',   1000),
  ('QUEEN',  9),
  ('ROOK',   5),
  ('BISHOP', 3),
  ('KNIGHT', 3),
  ('PAWN',   1);

INSERT INTO Piece(id, type_name, color, position_id, board_id) VALUES
    (123, 'ROOK', 'WHITE', 1, 15),
    (124, 'KNIGHT', 'WHITE', 9, 15),
    (125, 'BISHOP', 'WHITE', 17, 15),
    (126, 'QUEEN', 'WHITE', 25, 15),
    (127, 'KING', 'WHITE', 33, 15),
    (128, 'BISHOP', 'WHITE', 41, 15),
    (129, 'KNIGHT', 'WHITE', 49, 15),
    (130, 'ROOK', 'WHITE', 57, 15),
    (131, 'PAWN', 'WHITE', 2, 15),
    (132, 'PAWN', 'WHITE', 10, 15),
    (133, 'PAWN', 'WHITE', 18, 15),
    (134, 'PAWN', 'WHITE', 26, 15),
    (135, 'PAWN', 'WHITE', 34, 15),
    (136, 'PAWN', 'WHITE', 42, 15),
    (137, 'PAWN', 'WHITE', 50, 15),
    (138, 'PAWN', 'WHITE', 58, 15),
    (139, 'ROOK', 'BLACK', 8, 15),
    (140, 'KNIGHT', 'BLACK', 16, 15),
    (141, 'BISHOP', 'BLACK', 24, 15),
    (142, 'QUEEN', 'BLACK', 32, 15),
    (143, 'KING', 'BLACK', 40, 15),
    (144, 'BISHOP', 'BLACK', 48, 15),
    (145, 'KNIGHT', 'BLACK', 56, 15),
    (146, 'ROOK', 'BLACK', 64, 15),
    (147, 'PAWN', 'BLACK', 7, 15),
    (148, 'PAWN', 'BLACK', 15, 15),
    (149, 'PAWN', 'BLACK', 23, 15),
    (150, 'PAWN', 'BLACK', 31, 15),
    (151, 'PAWN', 'BLACK', 39, 15),
    (152, 'PAWN', 'BLACK', 47, 15),
    (153, 'PAWN', 'BLACK', 55, 15),
    (154, 'PAWN', 'BLACK', 63, 15);

-- Match 20: segunda partida del desafío 1, finalizada en tablas (sin winner)
INSERT INTO chess_board (id, white_turn, current_turn_start, jaque) VALUES (20, true, CURRENT_TIMESTAMP(), false);
INSERT INTO chess_match (id, name, white_id, black_id, winner_id, board_id, type, start, finish, turn_duration)
VALUES (20, 'Revancha', 4, 5, NULL, 20, 0, '2026-07-05 09:00:00', '2026-07-05 09:25:00', 600);

-- Match 21: partida del desafío 2, todavía sin finalizar
INSERT INTO chess_board (id, white_turn, current_turn_start, jaque) VALUES (21, true, CURRENT_TIMESTAMP(), false);
INSERT INTO chess_match (id, name, white_id, black_id, winner_id, board_id, type, start, finish, turn_duration)
VALUES (21, 'Primera partida de agosto', 5, 7, NULL, 21, 0, '2026-08-03 10:00:00', NULL, 600);

-- Matches 22-24: usadas solo por el desafío 3, para cubrir en el Test 6 varias
-- casuísticas de una vez (victoria+empate acumulados, derrota explícita a 0
-- puntos, y una partida sin finalizar que no debe contar):
INSERT INTO chess_board (id, white_turn, current_turn_start, jaque) VALUES (22, true, CURRENT_TIMESTAMP(), false);
INSERT INTO chess_match (id, name, white_id, black_id, winner_id, board_id, type, start, finish, turn_duration)
VALUES (22, 'Desafio3 - partida 1', 4, 6, 4, 22, 0, '2026-07-10 09:00:00', '2026-07-10 09:20:00', 600);

INSERT INTO chess_board (id, white_turn, current_turn_start, jaque) VALUES (23, true, CURRENT_TIMESTAMP(), false);
INSERT INTO chess_match (id, name, white_id, black_id, winner_id, board_id, type, start, finish, turn_duration)
VALUES (23, 'Desafio3 - partida 2', 4, 7, NULL, 23, 0, '2026-07-11 09:00:00', '2026-07-11 09:25:00', 600);

INSERT INTO chess_board (id, white_turn, current_turn_start, jaque) VALUES (24, true, CURRENT_TIMESTAMP(), false);
INSERT INTO chess_match (id, name, white_id, black_id, winner_id, board_id, type, start, finish, turn_duration)
VALUES (24, 'Desafio3 - partida 3 (sin acabar)', 6, 7, NULL, 24, 0, '2026-07-12 09:00:00', NULL, 600);

-- ==========================================================
-- FriendlyChallenge: ya viene mapeada y con datos de ejemplo
-- ==========================================================
INSERT INTO friendly_challenge (id, start_date, end_date, total_matches, completed_matches) VALUES
    (1, '01/07/2026', '31/07/2026', 5, 2);
INSERT INTO friendly_challenge (id, start_date, end_date, total_matches, completed_matches) VALUES
    (2, '01/08/2026', '31/08/2026', 3, 0);
INSERT INTO friendly_challenge (id, start_date, end_date, total_matches, completed_matches) VALUES
    (3, '10/07/2026', '20/07/2026', 3, 2);

INSERT INTO friendly_challenge_matches (friendly_challenge_id, chess_match_id) VALUES
    (1, 15),
    (1, 20),
    (2, 21),
    (3, 22),
    (3, 23),
    (3, 24);

INSERT INTO friendly_challenge_participants (friendly_challenge_id, user_id) VALUES
    (1, 4),
    (1, 5),
    (2, 5),
    (2, 6),
    (2, 7),
    (3, 4),
    (3, 6),
    (3, 7);

-- Nótese que, deliberadamente, no se insertan filas de ChallengeAnnouncement,
-- AnnouncementResponse ni de su tabla intermedia de recipients: esa es la parte
-- del script de inicialización que corresponde completar en los Tests 3 y 4.


